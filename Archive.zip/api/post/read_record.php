<?php
header('Access-Control-Allow-Origin: *');
header('Content-type: application/json');

include('../../models/read_receptionist.php');
include('../../config/db_con.php');